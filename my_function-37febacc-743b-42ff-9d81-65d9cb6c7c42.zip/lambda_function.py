import json
import configparser
import psycopg2
from flow import execute_flow

def lambda_handler(event, context):
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()

    execute_flow(cur, conn)

    conn.close()
